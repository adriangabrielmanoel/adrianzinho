/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.aula2;

/**
 *
 * @author aluno
 */
public class Aula2 {

    public static void main(String[] args) {
      construtor eu = new construtor();
        System.out.println(eu.nome);
        System.out.println(eu.idade);
    }
}

