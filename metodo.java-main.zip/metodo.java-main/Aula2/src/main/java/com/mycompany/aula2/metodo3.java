/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aula2;

/**
 *
 * @author aluno
 */
public class metodo3 {
 
    
    void mostraNome(String nome){
      System.out.println("None é"+nome);
    
    }
        
     int calcularIdade(int atual, int nascimento){
        return atual-nascimento;
    
    }
    
}
